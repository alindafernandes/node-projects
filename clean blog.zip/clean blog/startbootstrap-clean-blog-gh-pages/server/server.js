var http = require("http"),
    url = require("url"),
    path = require("path"),
    fs = require("fs"),
    port = process.env.PORT || 8080;

http.createServer(function(request, response) {

  var uri = url.parse(request.url).pathname
    , filename = path.join(process.cwd(), uri);

  fs.exists(filename, function(exists) {
    if(!exists) {
      response.writeHead(404, {"Content-Type": "text/plain"});
      response.write("404 Not Found\n");
      response.end();
      return;
    }

    if (fs.statSync(filename).isDirectory()) filename += '/index.html';

    fs.readFile(filename, "binary", function(err, file) {
      if(err) {        
        response.writeHead(500, {"Content-Type": "text/plain"});
        response.write(err + "\n");
        response.end();
        return;
      }

      response.writeHead(200);
      response.write(file, "binary");
      response.end();
    });
  });
}).listen(parseInt(port, 10));

console.log("Static file server running at\n  => http://localhost:" + port + "/\nCTRL + C to shutdown");







/*







var http = require('http');
const path = require('path');
const socketIO = require('socket.io');
const express = require('express');
const bodyParser = require('body-parser');

const publicPath = path.join(__dirname, '/startbootstrap-clean-blog-gh-pages'); 
const port = process.env.PORT || 8080;

var app = express();
var server = http.createServer(app);
var io = socketIO(server);

app.use(express.static(publicPath));


app.use(bodyParser.json());

//get all the posts
app.get('/posts', (request, response) => {
   console.log('Getting all the posts');
   response.send({
       "posts": posts
   });
});

//get specific post
app.get('/posts/:id', (request, response) => {
   var id = request.params.id;
   console.log('Getting post with id : ', id);
    response.send(posts[id]);

});

//create a post
app.post('/posts/:id', (request, response) => {
  // apiKey = request.headers['x-auth'];
 //  if(apiKey == 12345){  
   console.log('User authorised');
   var id = request.params.id;
   console.log('Setting the post with id', id);
    posts[id].available = request.body.available;  /////edit this part
  
    response.send();
    io.sockets.emit('statusChange', posts);
  /* } else{
       console.log('User unauthorised');
       response.status(401).send();
   }
/*});
*/


////////check if needed
/*
//create multiple posts with same content
app.post('/posts', (request, response) => {
    sensors = request.body.posts;
    console.log(posts);
    response.send();
});*/

/*

io.on('connection', (socket) => {
	console.log('New User connected');
    socket.emit('firstLoad', sensors);
    });

server.listen(port, () => {
	console.log(`server is up on port: ${port}`);
});
*/