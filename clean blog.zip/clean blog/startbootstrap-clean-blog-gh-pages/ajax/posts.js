$( document ).ready(function() {
       
    function getAllPosts(){
           $.ajax({
        url:'http://localhost:3000/posts',
        dataType:'json',
        type: 'get',
        success:function(response){
             var data = [{
            name: "alinda",
            color: "pink",
        },
        {
            name: "alinda",
            color: "pink",
        },
        {
            name: "alinda",
            color: "pink",
        }];
        var compiled_template = Hogan.compile("Hi i'm <strong>{{name}} </strong>and i like <strong>{{color}} </strong> !!");
        var rendered = compiled_template.render(data);
        document.getElementById('output').innerHTML=rendered;
        },
        error: function (err) {
            if(err){
                console.log('Stats not found');
            }
        }
    });
    }
   }