$( document ).ready(function() {
      /* $("#Logo").click(function{
                    if($(window).width()>1020){
                         $("#EasterEgg").fadeIn(500,function{
                            setTimeout(function(){
                                $('#EasterEgg').fadeOut(500);
                            }, 10000);
                        });
                    }                 
                });
        */
                $("#section1").show();
                $("#section2").hide();
                $('.tab').click(function() {
                    //alert(0);
                  if(this.id=="tab1"){
                      $("#section1").fadeIn(500);
                       $("#section2").hide();
                  }else{
                      $("#section2").fadeIn(500);
                      $("#section1").hide();
                      
                  }
                });
    
            
             
});
             