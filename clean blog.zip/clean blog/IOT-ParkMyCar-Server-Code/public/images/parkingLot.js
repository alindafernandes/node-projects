 $(document).ready(function(){
                var sensors = [0,1,2];
                
                function glowbulb(){
                    $("#logo").fadeOut(function(){
                        $("#logo").attr("src", "images/logo3_glow.png");
                        $("#logo").fadeIn(2000,glowbulb);    
                    });
                }
                glowbulb();
             
                
                var socket = io();
                var prevState = [
                  {
                        "available": true,
                        "flag":0
                    },
                     {
                        "available": true, 
                         "flag":0
                    },
                     {
                        "available": true,
                         "flag":0
                    }
                ];
                socket.on('statusChange', function(sensors) {
                    var count=0;
                     for(sensor in sensors){
                            var i=sensor;
                            
                            i++; 
                            if(sensors[sensor].available){
                                 $("#slot"+i).fadeOut(700);
                                  $("#tdSlot"+i).animate({},function(){
                                $("#tdSlot"+i).css("background-color","rgba(0,255,0,0.25)");
                            },1000);
                                 $("#slot"+i).fadeOut(3000);
                                count--;
                             }
                             else {
                                 $("#tdSlot"+i).animate({
                                backgroundColor: "rgba( 0, 0, 0, 0.7 )"
                            },2000);
                             $("#slot"+i).fadeIn(3000);
                                 count++;
                             }
                        $("#odometer1").html(count);
                        $("#odometer2").html(count);
                      
                    }
                   
                });
                });
                                
                                             
                

                