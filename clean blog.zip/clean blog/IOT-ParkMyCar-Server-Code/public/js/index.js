 $(document).ready(function(){
    // alert(1111);
                        $("#odometer1").html(3);
                        $("#odometer2").html(3);

                var count=3;
                function glowbulb(){
                    $("#logo").fadeOut(function(){
                        $("#logo").attr("src", "images/logo3_glow.png");
                        $("#logo").fadeIn(2000,glowbulb);    
                    });
                }
                glowbulb();
             
                
                var socket = io();
                var prevState = [
                  {
                        "available": true
                    },
                     {
                        "available": true
                    },
                     {
                        "available": true
                    }
                ];
                socket.on('statusChange', function(sensors) {
                    
                     for(sensor in sensors){
                            var i=sensor;
                            console.log(count);
                            i++; 
                            if(sensors[sensor].available && !prevState[sensor].available){
                                // $("#slot"+i).fadeOut(700);
                                  
 				$("#tdSlot"+i).animate({
                                	backgroundColor: "rgba(0,255,0,0.25)"
                            	},2000);
                                 $("#slot"+i).fadeOut(3000);
				//

                                count++;
                             }
				
                             else if(!sensors[sensor].available && prevState[sensor].available) {
                                 $("#tdSlot"+i).animate({
                                backgroundColor: "rgba( 0, 0, 0, 0.7 )"
                            },2000);
                             $("#slot"+i).fadeIn(3000);
                                 count--;
                             }
			prevState[sensor].available=sensors[sensor].available;
                        $("#odometer1").html(count);
                        $("#odometer2").html(count);
                      
                    }
                   
                });
     
     socket.on('firstLoad', function(sensors) {
                    var c2 =0;
                     for(sensor in sensors){
                            var i=sensor;
                            console.log(count);
                            i++; 
                            if(sensors[sensor].available) {
                                 $("#tdSlot"+i).css("background-color","rgba(0,255,0,0.25)");
                                 $("#slot"+i).hide(); 
                                 c2++;
                             }
				
                             else if(!sensors[sensor].available ) {
        
                            $("#tdSlot"+i).css("background-color","rgba( 0, 0, 0, 0.7 )");
                            $("#slot"+i).show();
                              
                                
                             }
			                 prevState[sensor].available=sensors[sensor].available;
                             $("#odometer1").html(count);
                             $("#odometer2").html(count);
                      
                    }
               count = c2;
                   
                });
            
    });
                                
                                             
                

                