$( document ).ready(function() {
         var yestDate = moment().subtract(1, 'days');
         yestDate = yestDate.format('YYYY-MM-DD').toString();
        //console.log(yestdate);
        getDailyStats(yestDate)
        
        var d = new Date();
         var year = d.getFullYear();
        getMonthlyStats(year);
        getYearlyStats();
        
    $("#yearPicker").hide(); 
    var $contents = $('.tab-content');
    $contents.slice(1).hide();
    
    $('.tab').click(function() {
        var $target = $('#' + this.id + 'show').show();
        $contents.not($target).hide();
        $("#chartMenu").html($(this).text() + ' <span class="caret"></span>');
        $(".statistics li").removeClass("active");
        if(this.id=="tab1"){
            $("#dateTimePicker").show();
            $("#yearPicker").hide();
            $("#tab1").parent().addClass("active");
        }
        else if(this.id=="tab2"){
            $("#dateTimePicker").hide();
            $("#yearPicker").show();
            $("#tab2").parent().addClass("active");
            $("#yearPicker select").html();
            var year = new Date().getFullYear();
            for(var i = 2007; i <= year ; i++)
            {  
                if(year == i)
                    $("#yearPicker select").append("<option selected>"+ i +"</option>");
                else
                    $("#yearPicker select").append("<option>"+ i +"</option>");
            }
        }
        else{
            $("#dateTimePicker").hide();
            $("#yearPicker").hide();   
            $("#tab3").parent().addClass("active");
        }
    });
    
    function getYearlyStats(){
           $.ajax({
        url:'http://localhost:3000/statistics/years',
        dataType:'json',
        type: 'get',
        success:function(response){
            
            var chart3 = new CanvasJS.Chart("tab3show",
		{
            width: 800,
			title:{
				text: "Yearly Parking Report"
			},   
                        animationEnabled: true,  
			axisY:{ 
				title: "No Of Vehicles",
				includeZero: true,
                    interval: 2500,
                maximum: 20000
			},
			axisX: {
				title: "Year",
                labelAngle: -80,
				interval: 1, 
                //minimum: 1,
                includeZero: true
			},
			toolTip: {
				shared: true,
				content: function(e){
					var body = new String;
					var head ;
					for (var i = 0; i < e.entries.length; i++){
						var  str = "<span style= 'color:"+e.entries[i].dataSeries.color + "'> " + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong>'' <br/>" ; 
						body = body.concat(str);
					}
					head = "<span style = 'color:DodgerBlue; '><strong>"+ (e.entries[0].dataPoint.label) + "</strong></span><br/>";

					return (head.concat(body));
				}
			},
			data: [
			{        
				type: "spline",
				showInLegend: false,
				name: "Yearly Report",
				dataPoints: [
				{label: response[0].year , y: response[0].total} ,     
				{label: response[1].year, y: response[1].total} ,     
				{label: response[2].year, y: response[2].total} ,     
				{label: response[3].year, y: response[3].total} ,     
				{label: response[4].year, y: response[4].total} ,     
				{label: response[5].year, y: response[5].total} ,     
				{label: response[6].year, y: response[6].total} ,     
				{label: response[7].year, y: response[7].total} ,                                // CHANGE IDEXES IMPORTANT !!!!
				{label: response[8].year, y: response[8].total} ,     
				{label: response[9].year, y: response[9].total} ,     
				]
			},
			],
		});
            chart3.render();
        },
        error: function (err) {
            if(err){
                console.log('Stats not found');
            }
        }
    });
    }
    function getMonthlyStats(year){
          $.ajax({
        url:'http://localhost:3000/statistics/monthly/'+year,
        dataType:'json',
        type: 'get',
        success:function(response){
            var chart2 = new CanvasJS.Chart("tab2show",
		{
            width: 800,
			title:{
				text: "Monthly Parking Report"
			},   
                        animationEnabled: true,  
			axisY:{ 
				title: "No Of Vehicles",
				includeZero: true,
                interval: 500,
                maximum: 2000
			},
			axisX: {
				title: "Months",
                labelAngle: -80,
				interval: 1, 
                //minimum: 1,
                includeZero: true
			},
			toolTip: {
				shared: true,
				content: function(e){
					var body = new String;
					var head ;
					for (var i = 0; i < e.entries.length; i++){
						var  str = "<span style= 'color:"+e.entries[i].dataSeries.color + "'> " + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong>'' <br/>" ; 
						body = body.concat(str);
					}
					head = "<span style = 'color:DodgerBlue; '><strong>"+ (e.entries[0].dataPoint.label) + "</strong></span><br/>";

					return (head.concat(body));
				}
			},
			data: [
			{        
				type: "spline",
				showInLegend: false,
				name: "Monthly Report",
				dataPoints: [
                {label: "January" , y: response.months[0].carCount} ,
				{label: "February" , y: response.months[1].carCount} ,     
				{label: "March" , y: response.months[2].carCount} ,     
				{label: "April" , y: response.months[3].carCount} ,     
				{label: "May" , y: response.months[4].carCount} ,     
				{label: "June" , y: response.months[5].carCount} ,     
				{label: "July" , y: response.months[6].carCount} ,     
				{label: "August" , y: response.months[7].carCount} ,     
				{label: "September" , y: response.months[8].carCount} ,     
				{label: "October" , y: response.months[9].carCount} ,     
				{label: "November" , y: response.months[10].carCount} ,     
				{label: "December" , y: response.months[11].carCount}
				]
			},
			],
		});
             chart2.render(); 
        },
        error: function (err) {
            if(err){
                console.log('Stats not found');
            }
        }
    });
              
        
         
        
    }
    function getDailyStats(date){
       
    $.ajax({
        url:'http://localhost:3000/statistics/daily/'+date,
        dataType:'json',
        type: 'get',
        success:function(response){
            console.log(response.hours);
            
            var values = [];
            values =  response.hours;
            var chart1 = new CanvasJS.Chart("tab1show",
	        {
                width: 800,
                title:{
                    text: "Daily Parking Report"
                },   
                            animationEnabled: true,  
                axisY:{ 
                    title: "No Of Vehicles",
                    includeZero: true,
                    interval: 5,
                    maximum: 20
                },
                axisX: {
                    title: "Time",
                    labelAngle: -80,
                    interval: 1, 
                    //minimum: 1,
                    includeZero: true
                },
                toolTip: {
                    shared: true,
                    content: function(e){
                        var body = new String;
                        var head ;
                        for (var i = 0; i < e.entries.length; i++){
                            var  str = "<span style= 'color:"+e.entries[i].dataSeries.color + "'> " + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong>'' <br/>" ; 
                            body = body.concat(str);
                        }
                        head = "<span style = 'color:DodgerBlue; '><strong>"+ (e.entries[0].dataPoint.label) + "</strong></span><br/>";

                        return (head.concat(body));
                    }
                },
                data: [
                {        
                    type: "spline",
                    showInLegend: false,
                    name: "Hourly Report",
                    dataPoints: [
                    {label: "12am" , y: values[0].carCount} ,
                    {label: "1am" , y: values[1].carCount} ,     
                    {label: "2am" , y: values[2].carCount} ,     
                    {label: "3am" , y: values[3].carCount} ,     
                    {label: "4am" , y: values[4].carCount} ,     
                    {label: "5am" , y: values[5].carCount} ,     
                    {label: "6am" , y: values[6].carCount} ,     
                    {label: "7am" , y: values[7].carCount} ,     
                    {label: "8am" , y: values[8].carCount} ,     
                    {label: "9am" ,y: values[9].carCount} ,     
                    {label: "10am" , y: values[10].carCount} ,     
                    {label: "11am" , y: values[11].carCount} ,     
                    {label: "12pm" , y: values[12].carCount} ,
                    {label: "1pm" , y: values[13].carCount} ,     
                    {label: "2pm" , y: values[14].carCount} ,     
                    {label: "3pm" , y: values[15].carCount} ,     
                    {label: "4pm" ,y: values[16].carCount} ,     
                    {label: "5pm" , y: values[17].carCount} ,     
                    {label: "6pm" , y: values[18].carCount} ,     
                    {label: "7pm" , y:  values[19].carCount} ,     
                    {label: "8pm" , y: values[20].carCount} ,     
                    {label: "9pm" , y: values[21].carCount} ,     
                    {label: "10pm" , y: values[22].carCount} ,     
                    {label: "11pm" , y: values[23].carCount} 
                    ]
                }
                ]
            });
            chart1.render();
            $('#tab1show').show();
         
        },
        error: function (err) {
            if(err){
                $('#tab1show').css("background","white");
                $('#tab1show').css("height","400px");
                $('#tab1show').css("width","800px");
                $('#tab1show').html("<center><p style = \"padding: 30px 0px; font-size: 50px; font-family: Calibri\">No Data</p></center>");
                $('#tab1show p').hide();
                $('#tab1show p').fadeIn(1000);
                console.log('Stats not found');
            }
        }
    });
    
}
      $("#yearPicker select").on('change', function(){
            //alert($("#yearPicker select").val());
            getMonthlyStats($("#yearPicker select").val());
    });
    

          


    $( "#datepicker" ).datepicker({
        changeMonth: true,
        changeYear: true,
        onSelect: function(dateText, inst) {
            var dt = $(this).datepicker("getDate");
            var formated_date = dt.getFullYear() + "-" + (dt.getMonth()+1) + "-" + dt.getDate();
            //alert(formated_date);
            
              getDailyStats(formated_date);
            

        }
    });
    
			/*var chart1 = new CanvasJS.Chart("tab1show",
		{
            width: 800,
			title:{
				text: "Daily Parking Report"
			},   
                        animationEnabled: true,  
			axisY:{ 
				title: "No Of Vehicles",
				includeZero: true,
                interval: 5,
                maximum: 20
			},
			axisX: {
				title: "Time",
                labelAngle: -80,
				interval: 1, 
                //minimum: 1,
                includeZero: true
			},
			toolTip: {
				shared: true,
				content: function(e){
					var body = new String;
					var head ;
					for (var i = 0; i < e.entries.length; i++){
						var  str = "<span style= 'color:"+e.entries[i].dataSeries.color + "'> " + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong>'' <br/>" ; 
						body = body.concat(str);
					}
					head = "<span style = 'color:DodgerBlue; '><strong>"+ (e.entries[0].dataPoint.label) + "</strong></span><br/>";

					return (head.concat(body));
				}
			},
			data: [
			{        
				type: "spline",
				showInLegend: false,
				name: "DailyReport",
				dataPoints: [
                {label: "12am" , y: 3.92} ,
				{label: "1am" , y: 3.92} ,     
				{label: "2am" , y: 3.31} ,     
				{label: "3am" , y: 3.85} ,     
				{label: "4am" , y: 3.60} ,     
				{label: "5am" , y: 3.24} ,     
				{label: "6am" , y: 3.22} ,     
				{label: "7am" , y: 3.06} ,     
				{label: "8am" , y: 3.37} ,     
				{label: "9am" , y: 3.47} ,     
				{label: "10am" , y: 3.79} ,     
				{label: "11am" , y: 3.98} ,     
				{label: "12pm" , y: 3.73} ,
                {label: "1pm" , y: 3.92} ,     
				{label: "2pm" , y: 3.31} ,     
				{label: "3pm" , y: 3.85} ,     
				{label: "4pm" , y: 3.60} ,     
				{label: "5pm" , y: 3.24} ,     
				{label: "6pm" , y: 3.22} ,     
				{label: "7pm" , y: 3.06} ,     
				{label: "8pm" , y: 3.37} ,     
				{label: "9pm" , y: 3.47} ,     
				{label: "10pm" , y: 3.79} ,     
				{label: "11pm" , y: 3.98} 
				]
			},
			],
		});
        var chart2 = new CanvasJS.Chart("tab2show",
		{
            width: 800,
			title:{
				text: "Monthly Parking Report"
			},   
                        animationEnabled: true,  
			axisY:{ 
				title: "No Of Vehicles",
				includeZero: true,
                interval: 20,
                maximum: 200
			},
			axisX: {
				title: "Months",
                labelAngle: -80,
				interval: 1, 
                //minimum: 1,
                includeZero: true
			},
			toolTip: {
				shared: true,
				content: function(e){
					var body = new String;
					var head ;
					for (var i = 0; i < e.entries.length; i++){
						var  str = "<span style= 'color:"+e.entries[i].dataSeries.color + "'> " + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong>'' <br/>" ; 
						body = body.concat(str);
					}
					head = "<span style = 'color:DodgerBlue; '><strong>"+ (e.entries[0].dataPoint.label) + "</strong></span><br/>";

					return (head.concat(body));
				}
			},
			data: [
			{        
				type: "spline",
				showInLegend: false,
				name: "DailyReport",
				dataPoints: [
                {label: "January" , y: 92} ,
				{label: "February" , y: 82} ,     
				{label: "March" , y: 121} ,     
				{label: "April" , y: 100} ,     
				{label: "May" , y: 185} ,     
				{label: "June" , y: 170} ,     
				{label: "July" , y: 165} ,     
				{label: "August" , y: 182} ,     
				{label: "September" , y: 194} ,     
				{label: "October" , y: 178} ,     
				{label: "November" , y: 165} ,     
				{label: "December" , y: 154}
				]
			},
			],
		});
        var chart3 = new CanvasJS.Chart("tab3show",
		{
            width: 800,
			title:{
				text: "Yearly Parking Report"
			},   
                        animationEnabled: true,  
			axisY:{ 
				title: "No Of Vehicles",
				includeZero: true,
                interval: 300,
                maximum: 3000
			},
			axisX: {
				title: "Year",
                labelAngle: -80,
				interval: 1, 
                //minimum: 1,
                includeZero: true
			},
			toolTip: {
				shared: true,
				content: function(e){
					var body = new String;
					var head ;
					for (var i = 0; i < e.entries.length; i++){
						var  str = "<span style= 'color:"+e.entries[i].dataSeries.color + "'> " + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong>'' <br/>" ; 
						body = body.concat(str);
					}
					head = "<span style = 'color:DodgerBlue; '><strong>"+ (e.entries[0].dataPoint.label) + "</strong></span><br/>";

					return (head.concat(body));
				}
			},
			data: [
			{        
				type: "spline",
				showInLegend: false,
				name: "DailyReport",
				dataPoints: [
				{label: "2008" , y: 992} ,     
				{label: "2009" , y: 1131} ,     
				{label: "2010" , y: 985} ,     
				{label: "2011" , y: 1460} ,     
				{label: "2012" , y: 1324} ,     
				{label: "2013" , y: 1522} ,     
				{label: "2014" , y: 1606} ,     
				{label: "2015" , y: 1637} ,     
				{label: "2016" , y: 1547} ,     
				{label: "2017" , y: 1879} ,     
				]
			},
			],
		});

         chart1.render();
         chart2.render();
         chart3.render();*/
    
});