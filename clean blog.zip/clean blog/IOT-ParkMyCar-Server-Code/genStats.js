var {mongoose} = require('./server/db/mongoose');
var {StatsHourly} = require('./server/models/statshourly');
var {StatsMonthly} = require('./server/models/statsmonthly');
const moment = require('moment');

var currentDate = moment(new Date());
currentDate = currentDate.format('YYYY-MM-DD');

var startDate = moment([2007, 0, 1]);
startDate = startDate.format('YYYY-MM-DD');
console.log(startDate);

var max = 3;
var min =0;

var createOrUpdateStats = (date) => {

console.log(date);



        console.log('Adding new stat');
        var stat = new StatsHourly({
           hours: [{
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },    
        {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },
                 {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           }, 
                  {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },
                 {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },    
         {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },
                  {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },     {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           }, 
                    {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },    
             {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },
                 {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },   {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           }, {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },    
        {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },
                 {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },   {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },
                    {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },    
         {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },
                  {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },   {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },{
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },    
        {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },
                  {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           },   {
               carCount: Math.floor(Math.random() * (max - min + 1)) + min
           } ] ,
            createdAt: date
                                   
                  });
    var total = 0;
    for(hour of stat.hours){
        total += hour.carCount;
    }    
    
    console.log(`Car count total: ${total}`);
    
    var year = moment(date).year();
    var month = moment(date).month();
    console.log(`Month: ${month} Year: ${year}`);
    StatsMonthly.findOne({
       year 
    }, (err, stats) => {
         if(err){
             console.log(err);
         } 
        if(!stats){
            console.log('adding new stats for year');
            var stat = new StatsMonthly({
                 months: [{
               carCount: 0
           },    
        {
               carCount: 0
           },
                 {
               carCount: 0 
           }, 
                  {
               carCount: 0
           },
                 {
               carCount: 0
           },    
         {
               carCount: 0
           },
                  {
               carCount: 0
           },     {
               carCount: 0
           }, 
                    {
               carCount: 0
           },    
             {
               carCount: 0
           },
                 {
               carCount: 0
           },   {
               carCount: 0
           }],
              year : year 
            });
            
            stat.months[month].carCount += total;
            saveStat(stat);
            
        } else {
            console.log('incrementing count');
            console.log(stats.months[month]);
             stats.months[month].carCount += total;
            console.log(stats.months[month]);
            saveStat(stats);
        }
    });
    
    savedays(stat);   
}

var saveStat = (stat) => {

          stat.save( (err) => {
            if(err){
                console.log(err);
        
            } else {
                console.log('Month saved');
                           
              startDate = moment(startDate).add(1, 'days');
                startDate = startDate.format('YYYY-MM-DD');
                if(startDate < currentDate){
         
               // console.log(startDate); 
                     createOrUpdateStats(startDate);
                }
                
            }
        });
         
           
        
}

var savedays = (stat) => {
            
        stat.save( (err) => {
            if(err){
                console.log(err);
            } else {
                //console.log('Object saved');
            }
        });
}

createOrUpdateStats(startDate);