# README #


### This repository has the RESTful API to know availability of parking slots ###

* Run the server.js method, server will listen to requests made to it
* 1.0 (Initial-Basic)

### How do I get set up? ###

* Ensure you have installed node, npm.
