const path = require('path');
const http = require('http');
const socketIO = require('socket.io');
const express = require('express');
const bodyParser = require('body-parser');
const moment = require('moment');

var {StatsHourly} = require('./models/statshourly');
var {StatsMonthly} = require('./models/statsmonthly');
var {createOrUpdateStatsDaily, createOrUpdateStatsMonthly, FindStatsByDate} = require('./utils/stats');
const publicPath = path.join(__dirname, '../public');
const port = process.env.PORT || 3000;

var app = express();
var server = http.createServer(app);
var io = socketIO(server);

app.use(express.static(publicPath));


app.use(bodyParser.json());

//readings from sensors , will be received from RasberryPi
var sensors =[ 
    {
        "available": true,
    },
     {
        "available": true, 
    },
     {
        "available": true,
    }
             ];

//get status of all slots
app.get('/slots', (request, response) => {
   console.log('Getting status of all slots');
   response.send({
       "slots": sensors
   });
});

//get status of specific slot
app.get('/slots/:id', (request, response) => {
   var id = request.params.id;
   console.log('Getting satus of spot ', id);
    response.send(sensors[id]);
  /* if(!sensors[id].available){ //if parking not available
       return response.send({"status": "Spot taken"});
   }
    response.send({"status": "Spot Avaialble"}); */
});

//set status of specific slot
app.post('/slots/:id', (request, response) => {
   apiKey = request.headers['x-auth'];
   if(apiKey == 12345){  
       console.log('User authorised');
   var id = request.params.id;
   console.log('Setting the status of spot', id);
    sensors[id].available = request.body.available;
    
    if(!sensors[id].available){
          createOrUpdateStatsDaily();
          createOrUpdateStatsMonthly();
    }
  
    response.send();
    io.sockets.emit('statusChange', sensors);
   } else{
       console.log('User unauthorised');
       response.status(401).send();
   }
});

//post status of all slots
app.post('/slots', (request, response) => {
    sensors = request.body.sensors;
    console.log(sensors);
    response.send();
});

//get statistics of specific date, that is for a given date get hourly stats
app.get('/statistics/daily/:date', (request, response) => {
   var date = moment(request.params.date) ; 
    date = date.format('YYYY-MM-DD');
    console.log('Getting status of date ', date);
    var stats = FindStatsByDate(date);
    console.log('stats are ', stats);
    
    StatsHourly.findOne( {
   
        createdAt: date
    }).then( (stats) => {
       if(!stats) {
           return response.status(404).send();
       }   

          response
            .status(200)
            .send({hours: stats.hours});
     });
    
   

});

 //get status of specific month, that is for a given year get the monthly stats
app.get('/statistics/monthly/:year', (request, response) => {
    var year = request.params.year;
 StatsMonthly.findOne({
       year 
    }).then( (stats) => {
     
     if(!stats){
         return response.status(404).send();
     }
     
      response
            .status(200)
            .send({months: stats.months});
 })

});

//get stats of last ten years
app.get('/statistics/years', (request, response) => {
   var d =  new Date();
   var currentYear = d.getFullYear();
   var startYear = currentYear-10;
    console.log(`from ${startYear} to ${currentYear}`);
    var yearStats = [];
    
/*    StatsMonthly.aggregate(
    [
        // Grouping pipeline
                
        { 
            $group: { 
                "_id": '$year', 
                "recommendCount": { "$sum": "$months.carCount" }
            }
        },]
        ,
    function(err,result) {
        console.log(result);
       // Result is an array of documents
    }
);*/
    //currentYear = 2018;
     StatsMonthly.aggregate(
    [{   
        $project: {
            year:"$year",
           total: { $sum: "$months.carCount"} 
            
        }
    }],
    function(err,result) {
        console.log(result);
       // Result is an array of documents
        var byYear = result.slice(0);
        console.log('returnval', result);
        console.log('byyear', byYear);
        byYear.sort(function(a,b) {
            return a.year - b.year;
        });
       var i=0;
        for( i=0; i<byYear.length; i++){
            if(byYear[i].year >= startYear){
                break;
            }
        }  
        var returnVal = [];
            for(var j=i; j<(i+10);j++){
                returnVal.push(byYear[j]);
            }
        console.log('Decade', returnVal);   
            
        
        response.send(returnVal);    
    }
);
    
    
});


io.on('connection', (socket) => {
	console.log('New User connected');
    socket.emit('firstLoad', sensors);
    });

server.listen(port, () => {
	console.log(`server is up on port: ${port}`);
});
