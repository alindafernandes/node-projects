const moment = require('moment');
var {mongoose} = require('./../db/mongoose');
var {StatsHourly} = require('./../models/statshourly');
var {StatsMonthly} = require('./../models/statsmonthly');


var createOrUpdateStatsMonthly = () => {
    var d =  new Date();
    var year = d.getFullYear();
    var month = d.getMonth();
    StatsMonthly.findOne({
       year 
    }, (err, stats) => {
         if(err){
             console.log(err);
         } 
        if(!stats){
            console.log('adding new stats for year');
            var stat = new StatsMonthly({
                 months: [{
               carCount: 0
           },    
        {
               carCount: 0
           },
                 {
               carCount: 0 
           }, 
                  {
               carCount: 0
           },
                 {
               carCount: 0
           },    
         {
               carCount: 0
           },
                  {
               carCount: 0
           },     {
               carCount: 0
           }, 
                    {
               carCount: 0
           },    
             {
               carCount: 0
           },
                 {
               carCount: 0
           },   {
               carCount: 0
           }],
              year : year 
            });
            
            stat.months[month].carCount++;
            saveStat(stat);
            
        } else {
            console.log('incrementing count');
            console.log(stats.months[month]);
            stats.months[month].carCount++;
            saveStat(stats);
        }
    });
    
    
}


var createOrUpdateStatsDaily = () => {
var now = moment(new Date());
var date = now.format('YYYY-MM-DD');
console.log(date);

var d = new Date();
var n = d.getHours();

StatsHourly.findOne( {
   
createdAt: date
}, (err, stats) => {
    if(err){
        console.log(err);
    } 
    if(!stats){
        console.log('Adding new stat');
        var stat = new StatsHourly({
           hours: [{
               carCount: 0
           },    
        {
               carCount: 0
           },
                 {
               carCount: 0 
           }, 
                  {
               carCount: 0
           },
                 {
               carCount: 0
           },    
         {
               carCount: 0
           },
                  {
               carCount: 0
           },     {
               carCount: 0
           }, 
                    {
               carCount: 0
           },    
             {
               carCount: 0
           },
                 {
               carCount: 0
           },   {
               carCount: 0
           }, {
               carCount: 0
           },    
        {
               carCount: 0
           },
                 {
               carCount: 0
           },   {
               carCount: 0
           },
                    {
               carCount: 0
           },    
         {
               carCount: 0
           },
                  {
               carCount: 0
           },   {
               carCount: 0
           },{
               carCount: 0
           },    
        {
               carCount: 0
           },
                  {
               carCount: 0
           },   {
               carCount: 0
           } ] ,
            createdAt: date
                                   
                  });
    
        console.log(n);
        
        stat.hours[n].carCount++;
       
        saveStat(stat);
        
    } else {
        console.log('incrementing count');
        console.log(stats.hours[n]);
        stats.hours[n].carCount++;
        saveStat(stats);
    }
});

}

var FindStatsByDate = (date) => {
    StatsHourly.findOne( {
   
createdAt: date
}, (err, stats) => {
        if(err) {
            console.log(err);
        } else {
            console.log(`Stats: ${stats}`);
            return stats;
        }
    });
};

var saveStat = (stat) => {
            
        stat.save( (err) => {
            if(err){
                console.log(err);
            } else {
                console.log('Object saved');
            }
        });
}


module.exports = {createOrUpdateStatsDaily, createOrUpdateStatsMonthly, FindStatsByDate};