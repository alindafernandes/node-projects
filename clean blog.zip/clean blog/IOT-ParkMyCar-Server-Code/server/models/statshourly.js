const mongoose = require('mongoose');

var statsHourlySchema =  new mongoose.Schema({
    hours : [{
         carCount : {type: Number, required: true}
    }]
    ,
    createdAt: {
        type: Date,
        required: true
    }
});


var StatsHourly = mongoose.model('StatsHourly',statsHourlySchema);
module.exports = {StatsHourly};