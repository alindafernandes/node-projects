const mongoose = require('mongoose');

var statsMonthlySchema =  new mongoose.Schema({
    months : [{
         carCount : {type: Number, required: true}
    }]
    ,
    year: {
        type: Number,
        required: true
    }
});

var StatsMonthly = mongoose.model('StatsMonthly',statsMonthlySchema);
module.exports = {StatsMonthly};