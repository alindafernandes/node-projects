const moment = require('moment');



/*
var {mongoose} = require('./db/mongoose');
var {StatsHourly} = require('./models/statshourly');

// hourly count
/*  var now = moment(new Date());

  var date = now.format('YYYY-MM-DD');
var date2 = new Date(date);
console.log(date2);
var stat = new StatsHourly({
   day : 'FRI',
   hours: [{
       carCount: 25
   },    
    {
       carCount: 100
   },
           {
       carCount: 50
   },   {
       carCount: 50
   }
          
          ],
    createdAt: date
}
);

stat.hours[0].carCount = 0;
stat.save( (err) => {
    if(err){
        console.log(err);
    } else {
        console.log('Object saved');
    }
});*/

/*var d = new Date();
var n = d.getHours();
console.log(`Hours: ${n}`);*/

var now = moment(new Date());

var date = now.format('YYYY-MM-DD');
 console.log(date);


    var d = new Date();
    var n = d.getHours();

StatsHourly.findOne( {
   
createdAt: date
}, (err, stats) => {
    if(err){
        console.log(err);
    } 
    if(!stats){
        console.log('Adding new stat');
        var stat = new StatsHourly({
           hours: [{
               carCount: 0
           },    
        {
               carCount: 0
           },
                 {
               carCount: 0 
           }, 
                  {
               carCount: 0
           },
                 {
               carCount: 0
           },    
         {
               carCount: 0
           },
                  {
               carCount: 0
           },     {
               carCount: 0
           }, 
                    {
               carCount: 0
           },    
             {
               carCount: 0
           },
                 {
               carCount: 0
           },   {
               carCount: 0
           }, {
               carCount: 0
           },    
        {
               carCount: 0
           },
                 {
               carCount: 0
           },   {
               carCount: 0
           },
                    {
               carCount: 0
           },    
         {
               carCount: 0
           },
                  {
               carCount: 0
           },   {
               carCount: 0
           },{
               carCount: 0
           },    
        {
               carCount: 0
           },
                  {
               carCount: 0
           },   {
               carCount: 0
           } ] ,
            createdAt: date
                                   
                  });
    
        console.log(n);
        
        stat.hours[n].carCount++;
       
        saveStat(stat);
        
    } else {
        console.log('incrementing count');
        console.log(stats.hours[n]);
        stats.hours[n].carCount++;
        saveStat(stats);
       /* stats.save( (err) => {
            console.log(err);
        })*/
    }
});

var saveStat = (stat) => {
            
        stat.save( (err) => {
            if(err){
                console.log(err);
            } else {
                console.log('Object saved');
            }
        });
}
*/
